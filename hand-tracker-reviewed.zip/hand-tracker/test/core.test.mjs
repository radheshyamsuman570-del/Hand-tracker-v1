import test from 'node:test';
import assert from 'node:assert/strict';
import { CONFIG } from '../public/js/config.js';
import { OneEuroBank, LandmarkSmoother } from '../public/js/smoothing.js';
import { QualityGovernor, FpsMeter } from '../public/js/quality.js';
import { Scene, F, packHands, unpackHands, coverTransform } from '../public/js/gl-core.js';

const P = CONFIG.smoothing;
const run = (bank, vals, dtMs = 16.7) => { const out = new Float32Array(1); let t = 0; const r = []; for (const v of vals) { bank.filter([v], t += dtMs, out); r.push(out[0]); } return r; };

test('smoothing: constant input stays constant', () => {
  const r = run(new OneEuroBank(1, P), Array(60).fill(0.5));
  r.forEach((v) => assert.ok(Math.abs(v - 0.5) < 1e-6));
});
test('smoothing: attenuates jitter at rest', () => {
  const noisy = Array.from({ length: 120 }, (_, i) => 0.5 + (i % 2 ? 0.002 : -0.002));
  const r = run(new OneEuroBank(1, P), noisy).slice(30);
  assert.ok(Math.max(...r) - Math.min(...r) < 0.002, 'output jitter should be well below input jitter (0.004)');
});
test('smoothing: tracks fast motion with small lag', () => {
  const ramp = Array.from({ length: 30 }, (_, i) => 0.2 + i * 0.02); // ~1.2 units/s
  const r = run(new OneEuroBank(1, P), ramp);
  assert.ok(ramp.at(-1) - r.at(-1) < 0.05, `lag was ${ramp.at(-1) - r.at(-1)}`);
});
test('smoothing: prune drops stale hands, banks are independent', () => {
  const s = new LandmarkSmoother(P); const a = new Float32Array(63).fill(0.1), b = new Float32Array(63).fill(0.9);
  s.smooth(0, a, 0); s.smooth(1, b, 0);
  assert.equal(s.smooth(0, a, 16)[0].toFixed(3), '0.100');
  s.prune(1000); assert.equal(s.banks.size, 0);
});

const gcfg = CONFIG.quality;
const drive = (g, fps, seconds, t0) => { let t = t0, last = null; const end = t0 + seconds * 1000; while (t < end) { t += 1000 / fps; const r = g.frame(t); if (r !== null) last = r; } return { t, last }; };
test('governor: downgrades after 2 bad windows and never passes the ladder end', () => {
  const g = new QualityGovernor(gcg(), 0); let t = 0;
  for (let i = 0; i < 6; i++) ({ t } = drive(g, 10, 4.2, t));
  assert.equal(g.step, gcfg.ladder.length - 1);
});
function gcg() { return { ...gcfg, upgradeLockMs: 0 }; }
test('governor: upgrades after sustained headroom, not before', () => {
  const g = new QualityGovernor(gcg(), 2);
  let { t } = drive(g, 30, 4 * 2 - 0.1, 0); assert.equal(g.step, 2, 'too early');
  ({ t } = drive(g, 30, 8, t)); assert.ok(g.step < 2);
});
test('governor: upgrade lock prevents oscillation after a downgrade', () => {
  const g = new QualityGovernor({ ...gcfg, upgradeLockMs: 30000 }, 0);
  let { t } = drive(g, 10, 4.2, 0); assert.equal(g.step, 1);
  ({ t } = drive(g, 30, 20, t)); assert.equal(g.step, 1, 'locked');
  drive(g, 30, 30, t); assert.equal(g.step, 0, 'unlocked later');
});
test('fps meter', () => {
  const m = new FpsMeter(500); for (let i = 0; i <= 120; i++) m.tick(i * 1000 / 60);
  assert.ok(Math.abs(m.value - 60) < 2);
});

const hand = (slot, seed = 1) => ({ slot, lm: Float32Array.from({ length: 63 }, (_, i) => (i % 3 === 2 ? 0.01 : 0.3 + ((i * seed * 7) % 40) / 100)) });
test('scene: finite geometry within capacity, two hands', () => {
  const s = new Scene(CONFIG.render);
  const n = s.build([hand(0), hand(1, 3)], { w: 800, h: 450, vw: 960, vh: 540, dpr: 2 }, { skeleton: true, glow: true });
  assert.ok(n > 0 && n % (6 * F) === 0 && n <= s.vertices.length);
  for (let i = 0; i < n; i++) assert.ok(Number.isFinite(s.vertices[i]));
});
test('scene: toggles reduce geometry; trails fade to nothing', () => {
  const s = new Scene(CONFIG.render), v = { w: 800, h: 450, vw: 960, vh: 540, dpr: 1 };
  const full = s.build([hand(0)], v, { skeleton: true, glow: true });
  const skel = new Scene(CONFIG.render).build([hand(0)], v, { skeleton: true, glow: false });
  const none = new Scene(CONFIG.render).build([hand(0)], v, { skeleton: false, glow: false });
  assert.ok(full > skel && skel > none && none === 0);
  for (let i = 0; i < CONFIG.render.trailLength + 1; i++) s.build([], v, { skeleton: true, glow: true });
  assert.equal(s.build([], v, { skeleton: true, glow: true }), 0);
});
test('pack/unpack roundtrip and cover transform', () => {
  const hs = [hand(0), hand(1, 2)], back = unpackHands(packHands(hs), 2);
  assert.equal(back[1].slot, 1); assert.deepEqual(Array.from(back[1].lm), Array.from(hs[1].lm));
  const t = coverTransform(100, 100, 200, 100); assert.deepEqual([t.ox, t.oy, t.dw, t.dh], [-50, 0, 200, 100]);
});
