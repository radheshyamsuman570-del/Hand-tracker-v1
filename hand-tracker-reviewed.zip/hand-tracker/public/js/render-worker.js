// Render worker: owns the OffscreenCanvas + WebGL context. Draws once per message
// (driven by inference results), so no worker-side rAF is needed.
import { GlRenderer, unpackHands } from './gl-core.js';

let r = null;
self.onmessage = (e) => {
  const m = e.data;
  if (m.type === 'init') {
    try {
      r = new GlRenderer(m.canvas, m.cfg);
      r.resize(m.w, m.h, m.dpr);
      self.postMessage({ ok: true });
    } catch (err) {
      self.postMessage({ ok: false, error: String(err && err.message || err) });
    }
  } else if (!r) return;
  else if (m.type === 'resize') r.resize(m.w, m.h, m.dpr);
  else if (m.type === 'opts') r.setOptions(m.opts);
  else if (m.type === 'hands') r.render(unpackHands(m.data, m.n), m.vw, m.vh);
};
