// MediaPipe HandLandmarker wrapper: GPU delegate with CPU fallback, VIDEO running mode,
// synchronous detectForVideo (so frames can never queue), One Euro smoothing, stable slots.
import { LandmarkSmoother } from './smoothing.js';

export class HandTracker {
  constructor(mpCfg, trackerCfg, smoothingCfg) {
    this.mp = mpCfg; this.cfg = trackerCfg;
    this.smoother = new LandmarkSmoother(smoothingCfg);
    this.raw = new Float32Array(63);
    this.lastTs = 0; this.delegate = null; this.landmarker = null; this.mod = null; this.fileset = null;
  }

  async init(delegate = this.cfg.delegate) {
    if (!this.mod) {
      this.mod = await import(this.mp.bundleUrl);
      this.fileset = await this.mod.FilesetResolver.forVisionTasks(this.mp.wasmBase);
    }
    const make = (d) => this.mod.HandLandmarker.createFromOptions(this.fileset, {
      baseOptions: { modelAssetPath: this.mp.modelUrl, delegate: d },
      runningMode: 'VIDEO',
      numHands: this.cfg.numHands,
      minHandDetectionConfidence: this.cfg.minHandDetectionConfidence,
      minHandPresenceConfidence: this.cfg.minHandPresenceConfidence,
      minTrackingConfidence: this.cfg.minTrackingConfidence,
    });
    this.landmarker?.close();
    try {
      this.landmarker = await make(delegate); this.delegate = delegate;
    } catch (err) {
      if (delegate === 'CPU') throw err;
      console.warn('GPU delegate unavailable, using CPU:', err);
      this.landmarker = await make('CPU'); this.delegate = 'CPU';
    }
    this.smoother.reset();
    this.lastTs = 0;
  }

  // Returns [{ slot: 0|1, lm: Float32Array(63) }] with smoothed normalized x,y,z.
  detect(video, nowMs) {
    const ts = Math.max(nowMs, this.lastTs + 1); // MediaPipe requires strictly increasing timestamps
    this.lastTs = ts;
    const res = this.landmarker.detectForVideo(video, ts);
    const sets = res.landmarks || [];
    const labels = res.handednesses || res.handedness || [];
    const used = [false, false];
    const hands = [];
    for (let i = 0; i < sets.length; i++) {
      let slot = labels[i]?.[0]?.categoryName === 'Right' ? 1 : 0;
      if (used[slot]) slot ^= 1;
      if (used[slot]) continue;
      used[slot] = true;
      const pts = sets[i];
      for (let k = 0; k < 21; k++) {
        this.raw[k * 3] = pts[k].x; this.raw[k * 3 + 1] = pts[k].y; this.raw[k * 3 + 2] = pts[k].z || 0;
      }
      hands.push({ slot, lm: this.smoother.smooth(slot, this.raw, ts) });
    }
    this.smoother.prune(ts);
    return hands;
  }
}
