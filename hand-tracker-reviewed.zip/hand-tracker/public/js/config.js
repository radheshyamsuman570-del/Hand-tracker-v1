// Central configuration. To self-host MediaPipe, download the bundle, the wasm/ folder
// and hand_landmarker.task into public/vendor/ and point these three URLs there.
const MP = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';

export const CONFIG = {
  mediapipe: {
    bundleUrl: `${MP}/vision_bundle.mjs`,
    wasmBase: `${MP}/wasm`,
    modelUrl: 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task',
  },
  camera: { facingMode: 'user', frameRate: 60, aspect: 16 / 9 },
  tracker: {
    numHands: 2,
    minHandDetectionConfidence: 0.5,
    minHandPresenceConfidence: 0.5,
    minTrackingConfidence: 0.5,
    delegate: 'GPU', // falls back to CPU if GPU init or the first inference fails
  },
  // One Euro filter on normalized [0..1] coordinates (hence the large beta).
  smoothing: { minCutoff: 1.2, beta: 25, dCutoff: 1.0 },
  render: {
    jointRadius: 5.5, boneWidth: 3, glowScale: 3.2, trailLength: 9, trailDecay: 0.8,
    colors: [[1.0, 0.72, 0.2], [0.37, 0.78, 1.0]], // slot 0, slot 1
  },
  quality: {
    targetFps: 24, upgradeFps: 28, evaluateEveryMs: 2000,
    downgradeAfterBadWindows: 2, upgradeAfterGoodWindows: 5, upgradeLockMs: 30000,
    ladder: [960, 720, 640, 480],       // capture width per step
    dprLadder: [2, 1.5, 1.25, 1],       // overlay devicePixelRatio cap per step
  },
};

export function deviceProfile() {
  const ua = navigator.userAgent || '';
  const isAndroid = /Android/i.test(ua);
  const isIOS = /iPhone|iPad|iPod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const lowEnd = (navigator.hardwareConcurrency || 4) <= 4 || (navigator.deviceMemory || 4) <= 3;
  return {
    isAndroid, isIOS, lowEnd,
    isMobile: isAndroid || isIOS || /Mobi/i.test(ua),
    supportsWorker: typeof Worker !== 'undefined',
    supportsOffscreen: typeof OffscreenCanvas !== 'undefined' &&
      typeof HTMLCanvasElement !== 'undefined' &&
      typeof HTMLCanvasElement.prototype.transferControlToOffscreen === 'function',
  };
}
