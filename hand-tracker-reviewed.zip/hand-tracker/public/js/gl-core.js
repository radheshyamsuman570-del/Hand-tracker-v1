// Shared WebGL drawing core. Runs unchanged on the main thread or inside the render worker.
// Everything (bones, joints, glow, fingertip trails) is batched into ONE draw call per frame.
export const F = 9; // floats per vertex: x, y, u, v, r, g, b, a, soft
export const CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11],
  [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [17, 18], [18, 19], [19, 20], [0, 17],
];
export const TIPS = [4, 8, 12, 16, 20];
export const DEFAULT_OPTS = { skeleton: true, glow: true };
const MAX_QUADS = 512;

// Hands cross the worker boundary as one transferable Float32Array: [slot, 63 floats] per hand.
export function packHands(hands) {
  const out = new Float32Array(hands.length * 64);
  hands.forEach((h, i) => { out[i * 64] = h.slot; out.set(h.lm, i * 64 + 1); });
  return out;
}
export function unpackHands(buf, n) {
  const hands = [];
  for (let i = 0; i < n; i++) hands.push({ slot: buf[i * 64], lm: buf.subarray(i * 64 + 1, i * 64 + 64) });
  return hands;
}

// Maps normalized video coords to canvas px, matching CSS object-fit: cover.
export function coverTransform(w, h, vw, vh) {
  const s = Math.max(w / vw, h / vh), dw = vw * s, dh = vh * s;
  return { ox: (w - dw) / 2, oy: (h - dh) / 2, dw, dh };
}

function vert(o, out, x, y, u, v, c, a, s) {
  out[o] = x; out[o + 1] = y; out[o + 2] = u; out[o + 3] = v;
  out[o + 4] = c[0]; out[o + 5] = c[1]; out[o + 6] = c[2]; out[o + 7] = a; out[o + 8] = s;
  return o + F;
}
function disc(out, o, cx, cy, r, c, a, s) {
  if (o + 6 * F > out.length) return o;
  o = vert(o, out, cx - r, cy - r, -1, -1, c, a, s); o = vert(o, out, cx + r, cy - r, 1, -1, c, a, s);
  o = vert(o, out, cx + r, cy + r, 1, 1, c, a, s); o = vert(o, out, cx - r, cy - r, -1, -1, c, a, s);
  o = vert(o, out, cx + r, cy + r, 1, 1, c, a, s); return vert(o, out, cx - r, cy + r, -1, 1, c, a, s);
}
function bone(out, o, x0, y0, x1, y1, width, c, a, s) {
  if (o + 6 * F > out.length) return o;
  const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy) || 1;
  const nx = (-dy / len) * width * 0.5, ny = (dx / len) * width * 0.5;
  o = vert(o, out, x0 + nx, y0 + ny, 1, 0, c, a, s); o = vert(o, out, x0 - nx, y0 - ny, -1, 0, c, a, s);
  o = vert(o, out, x1 - nx, y1 - ny, -1, 0, c, a, s); o = vert(o, out, x0 + nx, y0 + ny, 1, 0, c, a, s);
  o = vert(o, out, x1 - nx, y1 - ny, -1, 0, c, a, s); return vert(o, out, x1 + nx, y1 + ny, 1, 0, c, a, s);
}

export class Scene {
  constructor(cfg) {
    this.cfg = cfg;
    this.vertices = new Float32Array(MAX_QUADS * 6 * F);
    this.px = new Float32Array(42);
    this.trails = [0, 1].map(() => TIPS.map(() => ({ p: new Float32Array(cfg.trailLength * 2), n: 0 })));
  }

  // Fills this.vertices; returns the number of floats written.
  build(hands, view, opts) {
    const { cfg, vertices: out, px } = this;
    const { w, h, vw, vh, dpr } = view;
    const t = coverTransform(w, h, vw || w, vh || h);
    const N = cfg.trailLength, present = [false, false];
    let o = 0;

    for (const hand of hands) {
      const slot = hand.slot & 1, lm = hand.lm, col = cfg.colors[slot], trail = this.trails[slot];
      present[slot] = true;
      for (let k = 0; k < 21; k++) {
        px[k * 2] = t.ox + lm[k * 3] * t.dw;
        px[k * 2 + 1] = t.oy + lm[k * 3 + 1] * t.dh;
      }
      TIPS.forEach((tip, i) => { // push newest fingertip position to the trail ring
        const tr = trail[i];
        tr.p.copyWithin(2, 0, (N - 1) * 2);
        tr.p[0] = lm[tip * 3]; tr.p[1] = lm[tip * 3 + 1];
        tr.n = Math.min(tr.n + 1, N);
      });

      const r0 = cfg.jointRadius * dpr, bw = cfg.boneWidth * dpr;
      if (opts.glow) {
        for (let k = 0; k < 21; k++) {
          const tip = TIPS.includes(k);
          o = disc(out, o, px[k * 2], px[k * 2 + 1], r0 * cfg.glowScale * (tip ? 1.2 : 0.8), col, tip ? 0.55 : 0.28, 1);
        }
      }
      if (opts.skeleton) {
        for (const [a, b] of CONNECTIONS) {
          o = bone(out, o, px[a * 2], px[a * 2 + 1], px[b * 2], px[b * 2 + 1], bw, col, 0.8, 0);
        }
        for (let k = 0; k < 21; k++) {
          const zs = Math.min(1.6, Math.max(0.7, 1 - lm[k * 3 + 2] * 2)); // nearer joints draw larger
          o = disc(out, o, px[k * 2], px[k * 2 + 1], r0 * zs * (TIPS.includes(k) ? 1.25 : 1), [1, 1, 1], 0.9, 0);
        }
      }
    }

    for (let s = 0; s < 2; s++) {
      for (let i = 0; i < TIPS.length; i++) {
        const tr = this.trails[s][i];
        if (!present[s]) tr.n = Math.max(0, tr.n - 1); // let trails fade out when the hand leaves
        if (!opts.glow) continue;
        for (let j = 0; j < tr.n; j++) {
          const a = 0.55 * Math.pow(cfg.trailDecay, j);
          const r = cfg.jointRadius * dpr * cfg.glowScale * 0.55 * (1 - (0.6 * j) / N);
          o = disc(out, o, t.ox + tr.p[j * 2] * t.dw, t.oy + tr.p[j * 2 + 1] * t.dh, r, cfg.colors[s], a, 1);
        }
      }
    }
    return o;
  }
}

const VS = `attribute vec2 aPos;attribute vec2 aUv;attribute vec4 aCol;attribute float aSoft;
uniform vec2 uRes;varying vec2 vUv;varying vec4 vCol;varying float vSoft;
void main(){vUv=aUv;vCol=aCol;vSoft=aSoft;
gl_Position=vec4(aPos.x/uRes.x*2.0-1.0,1.0-aPos.y/uRes.y*2.0,0.0,1.0);}`;
const FS = `precision mediump float;varying vec2 vUv;varying vec4 vCol;varying float vSoft;
void main(){float d=length(vUv);
float core=1.0-smoothstep(0.7,1.0,d);float glow=pow(max(1.0-d,0.0),2.0);
float a=mix(core,glow,vSoft)*vCol.a;gl_FragColor=vec4(vCol.rgb*a,a);}`;

export class GlRenderer {
  constructor(canvas, cfg) {
    this.canvas = canvas; this.scene = new Scene(cfg); this.opts = { ...DEFAULT_OPTS };
    this.w = canvas.width; this.h = canvas.height; this.dpr = 1; this.lost = false; this.dirty = true;
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.lost = true; });
    canvas.addEventListener('webglcontextrestored', () => { this._init(); this.lost = false; this.dirty = true; });
    this._init();
  }

  _init() {
    const gl = this.gl = this.canvas.getContext('webgl', {
      alpha: true, antialias: false, depth: false, stencil: false, premultipliedAlpha: true,
      powerPreference: 'high-performance', desynchronized: true, preserveDrawingBuffer: false,
    });
    if (!gl) throw new Error('WebGL unavailable');
    const sh = (type, src) => {
      const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    };
    const p = this.prog = gl.createProgram();
    gl.attachShader(p, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    gl.useProgram(p);
    this.uRes = gl.getUniformLocation(p, 'uRes');
    this.buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.bufferData(gl.ARRAY_BUFFER, this.scene.vertices.byteLength, gl.DYNAMIC_DRAW);
    const stride = F * 4;
    [['aPos', 2, 0], ['aUv', 2, 8], ['aCol', 4, 16], ['aSoft', 1, 32]].forEach(([n, size, off]) => {
      const loc = gl.getAttribLocation(p, n);
      gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, size, gl.FLOAT, false, stride, off);
    });
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE); // additive: overlapping glows brighten
    gl.clearColor(0, 0, 0, 0);
  }

  resize(w, h, dpr) {
    this.canvas.width = this.w = Math.max(1, w); this.canvas.height = this.h = Math.max(1, h);
    this.dpr = dpr; this.dirty = true;
  }
  setOptions(o) { Object.assign(this.opts, o); this.dirty = true; }

  render(hands, vw, vh) {
    if (this.lost) return;
    const n = this.scene.build(hands, { w: this.w, h: this.h, vw, vh, dpr: this.dpr }, this.opts);
    if (n === 0 && !this.dirty) return; // nothing drawn last frame and nothing now
    const { gl } = this;
    gl.viewport(0, 0, this.w, this.h);
    gl.uniform2f(this.uRes, this.w, this.h);
    gl.clear(gl.COLOR_BUFFER_BIT);
    if (n) {
      gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.scene.vertices.subarray(0, n));
      gl.drawArrays(gl.TRIANGLES, 0, n / F);
    }
    this.dirty = n > 0;
  }
}
