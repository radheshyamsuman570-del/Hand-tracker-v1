// FPS meter + adaptive quality governor (pure logic, no DOM; unit-tested).
export class FpsMeter {
  constructor(windowMs = 500) { this.windowMs = windowMs; this.start = 0; this.count = 0; this.value = 0; }
  tick(now) {
    if (!this.start) this.start = now;
    this.count++;
    const el = now - this.start;
    if (el >= this.windowMs) { this.value = (this.count * 1000) / el; this.count = 0; this.start = now; }
    return this.value;
  }
}

// Steps down the resolution ladder after sustained low FPS, steps back up after sustained
// headroom, and blocks upgrades for a while after any downgrade to avoid oscillation.
export class QualityGovernor {
  constructor(cfg, step = 0) {
    this.c = cfg; this.step = step; this.max = cfg.ladder.length - 1;
    this.lockUntil = 0; this.hold(0);
  }
  hold(now) { this.start = now; this.count = 0; this.bad = 0; this.good = 0; }
  frame(now) {
    this.count++;
    const el = now - this.start;
    if (el < this.c.evaluateEveryMs) return null;
    const fps = (this.count * 1000) / el;
    this.start = now; this.count = 0;
    return this._evaluate(fps, now);
  }
  _evaluate(fps, now) {
    const c = this.c;
    if (fps < c.targetFps) {
      this.good = 0;
      if (++this.bad >= c.downgradeAfterBadWindows && this.step < this.max) {
        this.bad = 0; this.step++; this.lockUntil = now + c.upgradeLockMs; return this.step;
      }
    } else if (fps >= c.upgradeFps) {
      this.bad = 0;
      if (++this.good >= c.upgradeAfterGoodWindows && this.step > 0 && now >= this.lockUntil) {
        this.good = 0; this.step--; return this.step;
      }
    } else { this.bad = 0; this.good = 0; }
    return null;
  }
}
