// Renderer facade. Prefers Worker + OffscreenCanvas; falls back to main-thread WebGL.
// Both expose: mode, canvas, render(hands, vw, vh), setOptions(o), setDpr(d), dispose().
import { GlRenderer, packHands } from './gl-core.js';

function measure(canvas, dprCap) {
  const dpr = Math.min(window.devicePixelRatio || 1, dprCap);
  const r = canvas.getBoundingClientRect();
  return { w: Math.max(1, Math.round(r.width * dpr)), h: Math.max(1, Math.round(r.height * dpr)), dpr };
}

function observe(canvas, getCap, apply) {
  const ro = new ResizeObserver(() => { const m = measure(canvas, getCap()); apply(m.w, m.h, m.dpr); });
  ro.observe(canvas);
  return ro;
}

function replaceCanvas(canvas) { // a canvas that was transferred offscreen cannot get a context
  const fresh = canvas.cloneNode(false);
  canvas.replaceWith(fresh);
  return fresh;
}

async function workerRenderer(canvas, cfg, dprCap) {
  let cap = dprCap;
  const worker = new Worker(new URL('./render-worker.js', import.meta.url), { type: 'module' });
  const m = measure(canvas, cap);
  const off = canvas.transferControlToOffscreen();
  const ready = new Promise((res, rej) => {
    const to = setTimeout(() => rej(new Error('render worker timed out')), 5000);
    worker.onmessage = (e) => { clearTimeout(to); e.data.ok ? res() : rej(new Error(e.data.error)); };
    worker.onerror = (ev) => { clearTimeout(to); rej(new Error(ev.message || 'render worker failed')); };
  });
  worker.postMessage({ type: 'init', canvas: off, cfg: cfg.render, ...m }, [off]);
  try { await ready; } catch (e) { worker.terminate(); throw e; }
  worker.onmessage = worker.onerror = null;
  const ro = observe(canvas, () => cap, (w, h, dpr) => worker.postMessage({ type: 'resize', w, h, dpr }));
  return {
    mode: 'worker', canvas,
    render(hands, vw, vh) {
      const data = packHands(hands);
      worker.postMessage({ type: 'hands', n: hands.length, data, vw, vh }, [data.buffer]);
    },
    setOptions(opts) { worker.postMessage({ type: 'opts', opts }); },
    setDpr(d) { cap = d; const s = measure(canvas, cap); worker.postMessage({ type: 'resize', ...s }); },
    dispose() { ro.disconnect(); worker.terminate(); },
  };
}

function mainRenderer(canvas, cfg, dprCap) {
  let cap = dprCap;
  const gl = new GlRenderer(canvas, cfg.render);
  const apply = (w, h, dpr) => gl.resize(w, h, dpr);
  const m = measure(canvas, cap); apply(m.w, m.h, m.dpr);
  const ro = observe(canvas, () => cap, apply);
  return {
    mode: 'main', canvas,
    render: (hands, vw, vh) => gl.render(hands, vw, vh),
    setOptions: (o) => gl.setOptions(o),
    setDpr(d) { cap = d; const s = measure(canvas, cap); apply(s.w, s.h, s.dpr); },
    dispose() { ro.disconnect(); },
  };
}

export async function createRenderer(canvas, cfg, profile, dprCap) {
  if (profile.supportsWorker && profile.supportsOffscreen) {
    try { return await workerRenderer(canvas, cfg, dprCap); }
    catch (err) { console.warn('Worker renderer unavailable, using main thread:', err); canvas = replaceCanvas(canvas); }
  }
  return mainRenderer(canvas, cfg, dprCap);
}
