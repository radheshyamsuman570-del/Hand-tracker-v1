// One Euro filter (Casiez et al., CHI 2012), vectorised over typed arrays.
// Smooths jitter at rest while staying responsive during fast motion.
const alphaOf = (cutoff, dt) => 1 / (1 + 1 / (2 * Math.PI * cutoff) / dt);

export class OneEuroBank {
  constructor(n, { minCutoff, beta, dCutoff }) {
    Object.assign(this, { n, minCutoff, beta, dCutoff, t: -1 });
    this.x = new Float64Array(n);
    this.dx = new Float64Array(n);
    this.prev = new Float64Array(n);
  }
  filter(input, tMs, out) {
    if (this.t < 0) {
      this.x.set(input); this.prev.set(input); this.dx.fill(0); this.t = tMs;
      out.set(input);
      return out;
    }
    const dt = Math.max(1e-3, (tMs - this.t) / 1000);
    this.t = tMs;
    const aD = alphaOf(this.dCutoff, dt);
    for (let i = 0; i < this.n; i++) {
      const v = input[i];
      this.dx[i] += aD * ((v - this.prev[i]) / dt - this.dx[i]);
      this.prev[i] = v;
      const a = alphaOf(this.minCutoff + this.beta * Math.abs(this.dx[i]), dt);
      this.x[i] += a * (v - this.x[i]);
      out[i] = this.x[i];
    }
    return out;
  }
}

// One bank per hand slot, so left and right never share filter state.
export class LandmarkSmoother {
  constructor(params, channels = 63) {
    this.params = params; this.n = channels; this.banks = new Map();
  }
  smooth(key, raw, tMs) {
    let b = this.banks.get(key);
    if (!b) { b = { f: new OneEuroBank(this.n, this.params), seen: tMs }; this.banks.set(key, b); }
    b.seen = tMs;
    return b.f.filter(raw, tMs, new Float32Array(this.n));
  }
  prune(tMs, maxAgeMs = 300) {
    for (const [k, b] of this.banks) if (tMs - b.seen > maxAgeMs) this.banks.delete(k);
  }
  reset() { this.banks.clear(); }
}
