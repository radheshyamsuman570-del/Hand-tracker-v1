import { CONFIG, deviceProfile } from './config.js';
import { CameraManager } from './camera.js';
import { HandTracker } from './tracker.js';
import { createRenderer } from './renderer.js';
import { FpsMeter, QualityGovernor } from './quality.js';

const $ = (id) => document.getElementById(id);
const video = $('camera-feed');
const q = CONFIG.quality;
const profile = deviceProfile();

const camera = new CameraManager(video, CONFIG.camera);
const tracker = new HandTracker(CONFIG.mediapipe, CONFIG.tracker, CONFIG.smoothing);
const fps = new FpsMeter(500);
let governor, renderer;
let step = profile.isMobile && profile.lowEnd ? 1 : 0; // weak phones start one rung lower
let auto = true, manualMirror = null, running = false, busy = false, started = false;
let latency = 0, handCount = 0, lastHud = 0;
const opts = { skeleton: true, glow: true };

function panel(title, detail, { spinner = false, button = null } = {}) {
  $('title').textContent = title; $('detail').textContent = detail;
  $('spinner').hidden = !spinner;
  $('start').hidden = !button; if (button) $('start').textContent = button;
  $('panel').classList.remove('gone');
}

function applyMirror() {
  const m = manualMirror ?? camera.mirroredByDefault;
  video.classList.toggle('mirrored', m);
  renderer.canvas.classList.toggle('mirrored', m);
  $('btn-mirror').setAttribute('aria-pressed', String(m));
}

function modeLabel() { return `${renderer.mode} · ${tracker.delegate?.toLowerCase()} · ${camera.video.videoWidth || '-'}p`; }

async function applyStep(s) {
  busy = true;
  step = s;
  try {
    await camera.setResolution(q.ladder[s]);
    renderer.setDpr(q.dprLadder[s]);
    tracker.smoother.reset();
  } finally { busy = false; governor.hold(performance.now()); }
}

// One frame of work, in order: detect -> smooth -> render. Never queues: the next callback is
// scheduled first, and detectForVideo is synchronous, so stale frames are skipped by design.
const useRvfc = 'requestVideoFrameCallback' in HTMLVideoElement.prototype;
let lastVideoTime = -1;
const schedule = () => (useRvfc ? video.requestVideoFrameCallback(onFrame) : requestAnimationFrame(onFrame));

async function onFrame(_now, meta) {
  if (!running) return;
  schedule();
  if (busy || video.readyState < 2) return;
  if (!useRvfc) { if (video.currentTime === lastVideoTime) return; lastVideoTime = video.currentTime; }

  const t0 = performance.now();
  let hands;
  try {
    hands = tracker.detect(video, t0);
  } catch (err) {
    if (tracker.delegate === 'GPU') { // some Android GPUs fail only at first inference
      busy = true; panel('Switching to CPU', 'GPU inference failed on this device.', { spinner: true });
      try {
        await tracker.init('CPU');
        $('panel').classList.add('gone');
      } catch (cpuErr) {
        console.error('CPU inference initialization failed:', cpuErr);
        running = false;
        panel('Hand tracking unavailable',
          `${cpuErr.message || cpuErr}. Reload the page and try again.`);
        $('start').hidden = false;
        $('start').textContent = 'Reload page';
        $('start').onclick = () => location.reload();
      } finally {
        busy = false;
      }
    } else { console.error(err); }
    return;
  }
  const t1 = performance.now();
  renderer.render(hands, video.videoWidth, video.videoHeight);
  const t2 = performance.now();

  const ms = meta?.captureTime ? t2 - meta.captureTime : t2 - t0; // capture-to-draw when the browser reports it
  latency = latency ? latency * 0.9 + ms * 0.1 : ms;
  handCount = hands.length;
  fps.tick(t2);
  if (t2 - lastHud > 500) {
    lastHud = t2;
    $('fps').textContent = fps.value.toFixed(0); $('lat').textContent = latency.toFixed(0);
    $('hands').textContent = handCount; $('mode').textContent = modeLabel();
  }
  if (auto && !busy) {
    const next = governor.frame(t2);
    if (next !== null) {
      applyStep(next).catch((err) => {
        console.warn('Automatic quality adjustment failed:', err);
        auto = false;
        $('btn-auto').setAttribute('aria-pressed', 'false');
      });
    }
  }
}

async function startCamera() {
  panel('Starting camera', 'Allow camera access when your browser asks.', { spinner: true });
  try {
    await camera.start(q.ladder[step]);
  } catch (err) {
    const denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
    panel(denied ? 'Camera access blocked' : 'Camera unavailable',
      denied ? 'Allow camera access in your browser settings, then try again.' : String(err.message || err),
      { button: 'Try again' });
    return;
  }
  video.classList.add('visible');
  $('panel').classList.add('gone');
  renderer.setDpr(q.dprLadder[step]);
  applyMirror();
  started = running = true;
  governor.hold(performance.now());
  schedule();
}

function bind() {
  $('start').onclick = startCamera;
  const toggle = (id, fn) => { const b = $(id); b.onclick = () => { const on = b.getAttribute('aria-pressed') !== 'true'; b.setAttribute('aria-pressed', String(on)); fn(on); }; };
  toggle('btn-skeleton', (on) => { opts.skeleton = on; renderer.setOptions({ skeleton: on }); });
  toggle('btn-glow', (on) => { opts.glow = on; renderer.setOptions({ glow: on }); });
  toggle('btn-auto', (on) => { auto = on; governor.hold(performance.now()); });
  $('btn-mirror').onclick = () => { manualMirror = !(manualMirror ?? camera.mirroredByDefault); applyMirror(); };
  $('btn-flip').onclick = async () => {
    if (!started || busy) return;
    busy = true;
    try { await camera.flip(q.ladder[step]); manualMirror = null; applyMirror(); tracker.smoother.reset(); }
    catch (err) { console.warn('Flip failed', err); }
    finally { busy = false; }
  };
  // Release the camera when the tab is hidden (battery, privacy); resume on return.
  document.addEventListener('visibilitychange', async () => {
    if (!started) return;
    if (document.hidden) { running = false; camera.stop(); }
    else {
      try { await camera.start(q.ladder[step]); running = true; lastVideoTime = -1; schedule(); governor.hold(performance.now()); }
      catch (err) { panel('Camera unavailable', String(err.message || err), { button: 'Try again' }); started = false; }
    }
  });
}

async function boot() {
  governor = new QualityGovernor(q, step);
  try {
    renderer = await createRenderer($('overlay'), CONFIG, profile, q.dprLadder[step]);
    await tracker.init();
  } catch (err) {
    console.error(err);
    renderer?.dispose();
    panel('Could not start', `${err.message || err}. Check your connection and that WebGL is enabled, then reload.`);
    return;
  }
  if (!navigator.mediaDevices?.getUserMedia) {
    panel('Camera not supported', 'This browser cannot access a camera. Use a current Chrome, Safari, or Firefox over HTTPS.');
    return;
  }
  bind();
  $('mode').textContent = modeLabel();
  panel('Ready', 'Tracking runs on your device. No video leaves your browser.', { button: 'Start camera' });
}
boot();
