// getUserMedia wrapper with live resolution changes and facing-mode flip.
export class CameraManager {
  constructor(video, cfg) {
    this.video = video; this.cfg = cfg; this.stream = null; this.facingMode = cfg.facingMode;
  }
  _size(width) { return { width, height: Math.round(width / this.cfg.aspect) }; }

  async start(width) {
    this.stop();
    const { width: w, height: h } = this._size(width);
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        facingMode: { ideal: this.facingMode },
        width: { ideal: w }, height: { ideal: h },
        frameRate: { ideal: this.cfg.frameRate },
      },
    });
    try {
      this.video.srcObject = this.stream;
      await this.video.play();
      if (!this.video.videoWidth) {
        await new Promise((resolve, reject) => {
          const onLoaded = () => { cleanup(); resolve(); };
          const onError = () => { cleanup(); reject(new Error('Camera video could not be loaded')); };
          const cleanup = () => {
            this.video.removeEventListener('loadedmetadata', onLoaded);
            this.video.removeEventListener('error', onError);
          };
          this.video.addEventListener('loadedmetadata', onLoaded, { once: true });
          this.video.addEventListener('error', onError, { once: true });
        });
      }
      return { width: this.video.videoWidth, height: this.video.videoHeight };
    } catch (err) {
      this.stop(); // Do not leave the camera LED/stream active after startup fails.
      throw err;
    }
  }

  async setResolution(width) {
    const track = this.stream?.getVideoTracks()[0];
    const { width: w, height: h } = this._size(width);
    if (!track) return this.start(width);
    try {
      await track.applyConstraints({ width: { ideal: w }, height: { ideal: h } });
      return { width: this.video.videoWidth, height: this.video.videoHeight };
    } catch {
      return this.start(width);
    }
  }

  async flip(width) {
    this.facingMode = this.facingMode === 'user' ? 'environment' : 'user';
    return this.start(width);
  }
  get mirroredByDefault() { return this.facingMode === 'user'; }

  stop() {
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    this.video.srcObject = null;
  }
}
